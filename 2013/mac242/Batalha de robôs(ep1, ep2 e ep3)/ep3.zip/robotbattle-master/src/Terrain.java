public class Terrain {
    
    private char character;
    
    public Terrain (char character) {
        this.character = character;
    }
    
    public char character() {
        return this.character;
    }
    
}

