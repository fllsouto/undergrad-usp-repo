public class DebugJav{
	public static void sayCrash(String argument){
		System.out.println("------------------------------------------");
		System.out.println("Program crashed HERE  : " + argument);
		System.out.println("------------------------------------------");
	}
}

