Para executar rode via shell o arquivo "readSource.pl" passando como parâmetro a entrada desejada ou 
digitando o conjunto de instruções quando for pedido.
