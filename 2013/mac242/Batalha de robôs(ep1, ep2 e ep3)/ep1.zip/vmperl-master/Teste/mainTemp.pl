#!/usr/bin/perl

use quickobj ;


print "ok doke \n";

$x = new foo;
$x->sayHello;