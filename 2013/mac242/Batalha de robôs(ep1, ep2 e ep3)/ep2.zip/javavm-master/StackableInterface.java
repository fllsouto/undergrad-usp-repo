import java.lang.*;
import java.util.*;

interface StackableInterface{
	public void printYourself();
	public double getValue();
}