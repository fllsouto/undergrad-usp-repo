Repositório criado para armaznar o código da Máquina Virtual feita m
Java para o EP2 de Laboratório de Programação 2 (Segundo Semestre de
2013).
